import { DEFAULT_EXTENSIONS, hostPatterns, normalizeDomain, normalizeExtension, } from "./rules.js";
import { applyI18n, loadSettings, saveSettings, t } from "./settings.js";
applyI18n();
const autoCapture = document.getElementById("auto-capture");
const rulesBody = document.getElementById("rules");
const newDomain = document.getElementById("new-domain");
const extensionsInput = document.getElementById("extensions");
const message = document.getElementById("message");
let current;
function show(text, isError = false) {
    message.textContent = text;
    message.className = isError ? "error" : "info";
}
function renderRules() {
    rulesBody.replaceChildren();
    current.rules.forEach((rule, i) => {
        const tr = document.createElement("tr");
        const tdDomain = document.createElement("td");
        tdDomain.textContent = rule.domain;
        const tdCookies = document.createElement("td");
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = rule.allowCookies;
        cb.setAttribute("aria-label", t("allowCookiesFor", rule.domain));
        cb.addEventListener("change", () => (current.rules[i].allowCookies = cb.checked));
        tdCookies.append(cb);
        const tdRemove = document.createElement("td");
        const rm = document.createElement("button");
        rm.textContent = t("remove");
        rm.addEventListener("click", () => {
            current.rules.splice(i, 1);
            renderRules();
        });
        tdRemove.append(rm);
        tr.append(tdDomain, tdCookies, tdRemove);
        rulesBody.append(tr);
    });
    document.getElementById("no-rules").hidden = current.rules.length > 0;
}
function readExtensions() {
    const parts = extensionsInput.value.split(/[,\s]+/).filter(Boolean);
    const normalized = parts.map(normalizeExtension);
    if (normalized.some((e) => e === null))
        return null;
    return [...new Set(normalized)];
}
document.getElementById("add-domain").addEventListener("click", () => {
    const d = normalizeDomain(newDomain.value);
    if (!d) {
        show(t("errInvalidDomain"), true);
        return;
    }
    if (!current.rules.some((r) => r.domain === d))
        current.rules.push({ domain: d, allowCookies: false });
    newDomain.value = "";
    renderRules();
});
document.getElementById("reset-extensions").addEventListener("click", () => {
    extensionsInput.value = DEFAULT_EXTENSIONS.join(", ");
});
// Solicitar permissões exige gesto do usuário: o pedido é feito direto no
// clique, antes de qualquer outra espera.
document.getElementById("save").addEventListener("click", () => {
    const extensions = readExtensions();
    if (!extensions || extensions.length === 0) {
        show(t("errInvalidExtensions"), true);
        return;
    }
    const want = autoCapture.checked;
    if (want && current.rules.length === 0) {
        show(t("errNeedDomain"), true);
        return;
    }
    const rules = current.rules.map((r) => ({ ...r }));
    const origins = hostPatterns(rules);
    const request = want
        ? browser.permissions.request({ permissions: ["downloads", "webRequest"], origins })
        : Promise.resolve(true);
    void request.then(async (granted) => {
        if (!granted) {
            show(t("errPermissionDenied"), true);
            autoCapture.checked = false;
            return;
        }
        // Remove acesso a domínios que saíram das regras (ou a todos, se desligado).
        const all = await browser.permissions.getAll();
        const keep = new Set(want ? origins : []);
        const remove = (all.origins ?? []).filter((o) => !keep.has(o));
        if (remove.length)
            await browser.permissions.remove({ origins: remove });
        if (!want)
            await browser.permissions.remove({ permissions: ["webRequest", "downloads"] });
        current = { autoCapture: want, rules, extensions };
        await saveSettings(current);
        show(t("saved"));
    });
});
void loadSettings().then((s) => {
    current = s;
    autoCapture.checked = s.autoCapture;
    extensionsInput.value = s.extensions.join(", ");
    renderRules();
});
