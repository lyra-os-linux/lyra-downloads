import { DEFAULT_SETTINGS } from "./rules.js";
export async function loadSettings() {
    const stored = (await browser.storage.local.get("settings")).settings;
    return { ...DEFAULT_SETTINGS, ...(stored ?? {}) };
}
export async function saveSettings(s) {
    await browser.storage.local.set({ settings: s });
}
export function t(key, subs) {
    return browser.i18n.getMessage(key, subs) || key;
}
/** Preenche elementos com `data-i18n="chave"`. */
export function applyI18n(root = document) {
    root.querySelectorAll("[data-i18n]").forEach((el) => {
        el.textContent = t(el.dataset.i18n);
    });
}
