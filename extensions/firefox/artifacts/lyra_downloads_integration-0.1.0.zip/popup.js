import { applyI18n, t } from "./settings.js";
applyI18n();
const statusEl = document.getElementById("status");
const detailEl = document.getElementById("status-detail");
const list = document.getElementById("entries");
async function refreshStatus() {
    const res = (await browser.runtime.sendMessage({ type: "status" }));
    statusEl.classList.remove("ok", "bad");
    if (res.kind === "ok") {
        statusEl.textContent = t("statusConnected");
        statusEl.classList.add("ok");
        const b = res.result?.backend;
        detailEl.textContent = b?.engine_running ? "" : (b?.engine_problem ?? t("statusEngineStopped"));
    }
    else {
        statusEl.textContent = t("statusUnavailable");
        statusEl.classList.add("bad");
        detailEl.textContent =
            res.kind === "host_missing" ? res.message : res.kind === "timeout" ? t("errTimeout") : res.message;
    }
}
async function refreshEntries() {
    const entries = (await browser.runtime.sendMessage({ type: "entries" }));
    list.replaceChildren();
    document.getElementById("entries-section").hidden = entries.length === 0;
    for (const e of entries.slice(0, 5)) {
        const li = document.createElement("li");
        const name = document.createElement("strong");
        name.textContent = e.filename || e.url;
        name.title = e.url;
        const msg = document.createElement("p");
        msg.textContent = e.message;
        li.append(name, msg);
        if (e.canRestart) {
            const b = document.createElement("button");
            b.textContent = t("restartInFirefox");
            b.addEventListener("click", async () => {
                await browser.runtime.sendMessage({ type: "restart", requestId: e.requestId });
                await refreshEntries();
            });
            li.append(b);
        }
        list.append(li);
    }
}
document.getElementById("open-app").addEventListener("click", async () => {
    const res = (await browser.runtime.sendMessage({ type: "open-app" }));
    if (res.kind === "ok")
        window.close();
    else
        detailEl.textContent = res.kind === "timeout" ? t("errTimeout") : res.message;
});
document.getElementById("open-options").addEventListener("click", () => {
    void browser.runtime.openOptionsPage();
    window.close();
});
void refreshStatus();
void refreshEntries();
